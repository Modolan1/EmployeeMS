import React from 'react'

export const Profile = () => {
  return (
    <div>Profile</div>
  )
}
 export default Profile